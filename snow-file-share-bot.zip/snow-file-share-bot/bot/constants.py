# constantes que não mudam com frequência
BOT_USERNAME = "SnowFileSharingBot"  # pode vir do .env também
