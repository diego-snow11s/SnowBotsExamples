from pathlib import Path
import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
BOT_USERNAME = os.getenv("BOT_USERNAME", "SnowFileSharingBot")
CHANNEL_ID = int(os.getenv("CHANNEL_ID", "-1003722693322"))

BASE_DIR = Path(__file__).resolve().parent.parent
